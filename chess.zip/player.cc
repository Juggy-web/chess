#include "player.h"

using namespace std;

 Player::~Player() {}  // Virtual destructor
